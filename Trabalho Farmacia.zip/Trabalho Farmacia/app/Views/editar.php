<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      body{
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4e9e9; 
        }
        .container{
            width: 80%;
            margin: 0 auto;
            margin-top: 300px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        button{
            background-color: #E0FFFF;
        }
    </style>
    <title>Farmácia</title>
</head>
<body>
      <div class="container">
            <h1>Editar Medicamento</h1>
            <form action="<?=$codigo?>" method="post" enctype="multipart/form-data">
                  <label for="nome">Nome:</label>
                  <input type="text" name="nome" value="<?=$nome?>">
                  <br>
                  <label for="laboratorio">Laboratório:</label>
                  <br>
                  <input type="radio" name="laboratorio" value="Aché" value="<?=$laboratorio?>" <?php if($laboratorio=="Aché"){echo "checked";}?>>
                  <label for="laboratorio">Aché</label>
                  <input type="radio" name="laboratorio" value="Cimed" value="<?=$laboratorio?>" <?php if($laboratorio=="Cimed"){echo "checked";}?>>
                  <label for="laboratorio">Cimed</label>
                  <input type="radio" name="laboratorio" value="EMS" value="<?=$laboratorio?>" <?php if($laboratorio=="EMS"){echo "checked";}?>>
                  <label for="laboratorio">EMS</label>
                  <input type="radio" name="laboratorio" value="Eurofarma" value="<?=$laboratorio?>" <?php if($laboratorio=="Eurofarma"){echo "checked";}?>>
                  <label for="laboratorio">Eurofarma</label>
                  <input type="radio" name="laboratorio" value="Neo Química" value="<?=$laboratorio?>" <?php if($laboratorio=="Neo Química"){echo "checked";}?>>
                  <label for="laboratorio">Neo Química</label>
                  <br>
                  <label for="preco">Preço:</label>
                  <input type="number" step="0.01" name="preco" value="<?=$preco?>">
                  <br>
                  <label for="quantidade">Quantidade:</label>
                  <input type="number" name="quantidade" value="<?=$quantidade?>">
                  <br>
                  <input type="submit" value="Editar">
            </form>
      </div>
</body>
</html>