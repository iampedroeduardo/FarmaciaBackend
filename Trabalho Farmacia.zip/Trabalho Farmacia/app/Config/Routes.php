<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/cadastro', 'Home::cadastro');
$routes->post('/cadastrar', 'Home::cadastrar');
$routes->post('/pesquisar', 'Home::pesquisar');
$routes->get('/deletar/(:num)', 'Home::deletar/$1');
$routes->get('/editar/(:num)', 'Home::editar/$1');
$routes->post('/editar/(:num)', 'Home::update/$1');